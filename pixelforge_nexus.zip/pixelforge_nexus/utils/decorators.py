from flask import abort
from flask_login import current_user
from functools import wraps

def role_required(*roles):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            if current_user.role not in roles:
                return abort(403)  # Forbidden
            return func(*args, **kwargs)
        return wrapper
    return decorator

