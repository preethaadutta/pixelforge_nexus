import os
from flask import Flask, render_template, redirect, url_for, request, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from models.models import db, User, Project, db, Assignment, Document
from flask_bcrypt import Bcrypt

from utils.decorators import role_required
from datetime import datetime
from utils.decorators import role_required

from werkzeug.utils import secure_filename
#from models.models import Document


app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/database.db'
#app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/database.db'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
UPLOAD_FOLDER = os.path.join('static', 'uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

db.init_app(app)
bcrypt = Bcrypt(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))



@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        user = User.query.filter_by(username=request.form['username']).first()
        if user and bcrypt.check_password_hash(user.password, request.form['password']):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid username or password')
    return render_template('login.html')

'''
@app.route('/register', methods=['GET', 'POST'])
@login_required
def register():
    if current_user.role != 'admin':
        return "Access Denied", 403

    if request.method == 'POST':
        hashed_pw = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        new_user = User(
            username=request.form['username'],
            email=request.form['email'],
            password=hashed_pw,
            role=request.form['role']
        )
        db.session.add(new_user)
        db.session.commit()
        flash('User registered!')
        return redirect(url_for('dashboard'))
    return render_template('register.html')
'''
@app.route('/register', methods=['GET', 'POST'])
@login_required
@role_required('admin')  # ✅ Only admins can access this
def register():
    if request.method == 'POST':
        hashed_pw = bcrypt.generate_password_hash(request.form['password']).decode('utf-8')
        new_user = User(
            username=request.form['username'],
            email=request.form['email'],
            password=hashed_pw,
            role=request.form['role']
        )
        db.session.add(new_user)
        db.session.commit()
        flash('User registered!')
        return redirect(url_for('dashboard'))
    return render_template('register.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

'''
@app.route('/dashboard')
@login_required
def dashboard():
    return f"<h1>Welcome {current_user.username} ({current_user.role})</h1>"
'''

@app.route('/dashboard')
@login_required
def dashboard():
    return render_template('dashboard.html')

@app.errorhandler(403)
def forbidden(e):
    return "<h1>403 Forbidden</h1><p>You don't have permission to access this page.</p>", 403

@app.route('/')
def home():
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))
'''
@app.route('/')
def home():
    return '<h1>PixelForge Nexus is Running ✅</h1>'
'''
@app.route('/projects')
@login_required
@role_required('admin')
def project_list():
    projects = Project.query.all()
    return render_template('projects.html', projects=projects)

@app.route('/projects/add', methods=['GET', 'POST'])
@login_required
@role_required('admin')
def add_project():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        deadline = datetime.strptime(request.form['deadline'], '%Y-%m-%d')
        new_project = Project(name=name, description=description, deadline=deadline)
        db.session.add(new_project)
        db.session.commit()
        flash('Project added!')
        return redirect(url_for('project_list'))
    return render_template('add_project.html')

@app.route('/projects/complete/<int:project_id>')
@login_required
@role_required('admin')
def complete_project(project_id):
    project = Project.query.get_or_404(project_id)
    project.status = 'Completed'
    db.session.commit()
    flash('Project marked as completed.')
    return redirect(url_for('project_list'))

@app.route('/my-projects')
@login_required
@role_required('lead')
def my_projects():
    projects = Project.query.all()  # Later: filter to only lead’s projects
    return render_template('my_projects.html', projects=projects)

@app.route('/my-assignments')
@login_required
@role_required('developer')
def my_assignments():
    assignments = Assignment.query.filter_by(developer_id=current_user.id).all()
    return render_template('my_assignments.html', assignments=assignments)

@app.route('/assign/<int:project_id>', methods=['GET', 'POST'])
@login_required
@role_required('lead')
def assign_developer(project_id):
    project = Project.query.get_or_404(project_id)
    developers = User.query.filter_by(role='developer').all()

    if request.method == 'POST':
        dev_id = int(request.form['developer_id'])
        # Prevent duplicate assignment
        if not Assignment.query.filter_by(project_id=project_id, developer_id=dev_id).first():
            new_assignment = Assignment(project_id=project_id, developer_id=dev_id)
            db.session.add(new_assignment)
            db.session.commit()
            flash('Developer assigned.')
        return redirect(url_for('my_projects'))

    return render_template('assign_developer.html', project=project, developers=developers)

@app.route('/upload/<int:project_id>', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'lead')
def upload_document(project_id):
    project = Project.query.get_or_404(project_id)

    if request.method == 'POST':
        file = request.files['document']
        if file:
            filename = secure_filename(file.filename)
            save_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(save_path)

            new_doc = Document(
                project_id=project.id,
                uploaded_by=current_user.username,
                filename=filename
            )
            db.session.add(new_doc)
            db.session.commit()
            flash('Document uploaded successfully.')

        return redirect(url_for('project_details', project_id=project.id))

    return render_template('upload_document.html', project=project)

@app.route('/project/<int:project_id>')
@login_required
def project_details(project_id):
    project = Project.query.get_or_404(project_id)
    documents = Document.query.filter_by(project_id=project.id).all()

    # Allow access if user is admin or lead or assigned developer
    if current_user.role == 'developer':
        assigned = Assignment.query.filter_by(project_id=project.id, developer_id=current_user.id).first()
        if not assigned:
            return "Access Denied", 403

    return render_template('project_details.html', project=project, documents=documents)

@app.route('/delete_project/<int:project_id>', methods=['POST'])
@login_required
def delete_project(project_id):
    if current_user.role != 'admin':
        return "Unauthorized", 403

    project = Project.query.get_or_404(project_id)
    
    # Delete related assignments and documents first to maintain DB integrity
    Assignment.query.filter_by(project_id=project.id).delete()
    Document.query.filter_by(project_id=project.id).delete()
    
    db.session.delete(project)
    db.session.commit()
    flash('Project has been deleted successfully.', 'success')
    return redirect(url_for('project_list'))
'''
@app.route('/users')
@login_required
def view_users():
    if current_user.role != 'admin':
        return "Unauthorized", 403

    users = User.query.all()
    return render_template('view_users.html', users=users)

@app.route('/users')
@login_required
def view_users():
    if current_user.role != 'admin':
        return "Unauthorized", 403

    users = User.query.all()
    return render_template('view_users.html', users=users)
'''
@app.route('/users')
@login_required
def admin_user_list():  # ✅ function name changed to avoid conflict
    if current_user.role != 'admin':
        return "Unauthorized", 403

    users = User.query.all()
    return render_template('view_users.html', users=users)

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

