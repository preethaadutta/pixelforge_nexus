# PixelForge Nexus

**PixelForge Nexus** is an online, collaborative project management solution designed for the current game development team. This system allows effective communication between the Admins, Project Leads and the Developers in a central stepped up platform. It aims for making the process of creating projects, assigning team, sharing documents in role-controlled environment more convenient. This system isolates privileges in a clear way, every role that has the right to do can do the actions that are pertinent to their responsibility. This system is built with the Flask framework as its backend and SQLite as the light-weight file-based database system. On the frontend, HTML, CSS, JavaScript, and Bootstrap were utilised to design a responsive user interface. Password hashing with bcrypt and secure authentication capabilities have been implemented to keep user log in credentials safe.

---

## System Features

- **Admin**: 
  - Admin can register new users and also register new users as per their roles like lead, developer etc 
  - Admin has full access to all of the projects in the system, regardless of ownership 
  - Admin can also create new projects and also mark any project as completed 
  - Admin can also upload documents for a project Admin has access to all project dashboards and also document records 
  - Admin can manage the whole system from the Admin dashboard 

- **Project Lead**:
  - Project Lead can view only the projects, which is assigned to them as the project owner 
  - Project Lead can assign one or more developers to a project 
  - Project Lead can upload project-specific documents for the usage by assigned developers
  - Project Lead can view detailed project information, which includes the status, deadline, and team members 
  - Project Lead cannot create or register new users 
  - Project Lead has a personalized dashboard, which is shown only their own projects 

- **Developer**:
  - Developer can view a list of projects, which are assigned to them by a Project Lead 
  - Developer can only view details and also deadlines of assigned projects 
  - Developer can only view documents uploaded for their assigned projects 
  - Developer can neither upload documents, nor assign developers, modify any project 
  - Developer dashboard displays only their assigned projects with the restricted access

- **Secure Authentication**: 
  - User passwords are hashed for security features using bcrypt.
  
- **Pages**:
  - **Login**: All users login to the system securely.
  - **Dashboard**: Dashboard shows the user-specific actions based on all roles (Admin, Lead, Developer).
  - **Projects**: Admins and Leads can add new project, remove, and mark existing projects as completed.
  - **Assign Developer**: Project Leads can assign developers to all projects.
  - **Project Details**: It shows project information and uploaded documents.
  - **Document Upload**: Admins and Leads can upload documents for their projects.

---

## Setup Instructions

### Prerequisites

1. **Python 3.x**: Ensure Python is installed on your machine. You can download it from [python.org](https://www.python.org/downloads/).
   
2. **Pip**: Install Python dependencies using pip (Python's package installer). 

### 1. Clone the Repository

```bash```

git clone https://github.com/yourusername/7032CEM-2526MAYSEP_YourStudentID.git
cd 7032CEM-2526MAYSEP_YourStudentID

### 2. Set up a Virtual Environment

- Create and activate a virtual environment to manage dependencies.

- **On Windows**:
```bash```

python -m venv venv
.\venv\Scripts\activate

- **On macOS/Linux**:
```bash```

python3 -m venv venv
source venv/bin/activate

### 3. Install Dependencies
Install the required Python packages from requirements.txt.

```bash```
pip install -r requirements.txt

### 4. Configure the Project
- The project uses SQLite as the database, so no additional database setup is required. However, you can modify the app.py file to configure different databases if needed.

### 5. Run the Project
- Run the Flask development server:

```bash```

python app.py

By default, the app will run at:
http://127.0.0.1:5000/

### 6. Accessing the App
- Navigate to /login to log in with any user credentials.
- Depending on the user role, the dashboard will change accordingly:
- Admin: Can create users and manage projects.
- Project Lead: Can assign developers and upload project documents.
- Developer: Can only view assigned projects and access documents.


### Troubleshooting
- Error: "Module not found"
- Ensure all dependencies are installed in the virtual environment by running:

```bash```

pip install -r requirements.txt
Issue with Flask not starting
Make sure the FLASK_APP environment variable is set:

```bash```

export FLASK_APP=app.py  # On macOS/Linux

set FLASK_APP=app.py     # On Windows

- Database not found
- The SQLite database should be created automatically. If it’s missing, try running the project once to trigger its creation.
