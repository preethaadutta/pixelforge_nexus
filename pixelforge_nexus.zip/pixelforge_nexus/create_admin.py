from models.models import db, User
from flask_bcrypt import Bcrypt
from app import app

bcrypt = Bcrypt(app)

'''
with app.app_context():
    password = bcrypt.generate_password_hash('admin123').decode('utf-8')
    #admin = User(username='admin', email='admin@example.com', password=password, role='admin')
    admin = User(username='admin', email='admin2@example.com', password=password, role='admin')
    db.session.add(admin)
    db.session.commit()
    print("Admin user created.")
'''

with app.app_context():
    existing_user = User.query.filter_by(email='admin@example.com').first()
    if not existing_user:
        password = bcrypt.generate_password_hash('admin123').decode('utf-8')
        admin = User(username='admin', email='admin@example.com', password=password, role='admin')
        db.session.add(admin)
        db.session.commit()
        print("✅ Admin user created.")
    else:
        print("⚠️ Admin user already exists.")
